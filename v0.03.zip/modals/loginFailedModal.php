<!-- The Modal -->
<div class="modal fade" id="modal-loginFailed" tabindex="-1" role="dialog" >
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalCenterTitle"><i class="fas fa-exclamation-triangle"></i> Error</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true" style="color:white;">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                Email or password does not match.

            </div>
        </div>
    </div>
</div>
<script>$('#modal-loginFailed').modal('show') </script>
