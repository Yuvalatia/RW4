<div class="row res-table">
    <div class="col-xs-6 col-md-3  tStat-res">
        <table>
            <tr>
                <td rowspan="2"><img class="icon-pic" src="icns/gold.png" alt="gold"></td>
                <td class="stat-name">Gold</td>
            </tr>
            <tr>
                <td><?php echo $userGold; ?></td>
            </tr>
        </table>
    </div>
    <div class="col-xs-6 col-md-3 tStat-res">
        <table>
            <tr>
                <td rowspan="2"><img class="icon-pic" src="icns/wood.png" alt="wood"></td>
                <td class="stat-name">Wood</td>
            </tr>
            <tr>
                <td><?php echo $userWood; ?></td>
            </tr>
        </table>
    </div>
    <div class="col-xs-6 col-md-3 tStat-res">
        <table>
            <tr>
                <td rowspan="2"><img class="icon-pic" src="icns/ore.png" alt="ore"></td>
                <td class="stat-name">Ore</td>
            </tr>
            <tr>
                <td><?php echo $userOre; ?></td>
            </tr>
        </table>
    </div>
    <div class="col-xs-6 col-md-3 tStat-res">
        <table>
            <tr>
                <td rowspan="2"><img class="icon-pic" src="icns/turns.png" alt="turns"></td>
                <td class="stat-name">Turns</td>
            </tr>
            <tr>
                <td><?php echo $userTurns; ?></td>
            </tr>
        </table>
    </div>
</div>
<hr>