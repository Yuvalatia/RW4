<?php

$dbServername = "localhost";
$dbUsername = "root";
$dbPassword = "";
$dbName = "rw4";

$conn = mysqli_connect($dbServername, $dbUsername, $dbPassword, $dbName);

/*
<?php

$dbServername = "localhost";
$dbUsername = "id10255855_root";
$dbPassword = "1q2w3e4r5t6y";
$dbName = "id10255855_localhost";

$conn = mysqli_connect($dbServername, $dbUsername, $dbPassword, $dbName);


?>
 */
?>